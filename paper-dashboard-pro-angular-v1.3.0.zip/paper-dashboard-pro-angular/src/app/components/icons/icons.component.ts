import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'icons-cmp',
    templateUrl: 'icons.component.html'
})

export class IconsComponent{}
