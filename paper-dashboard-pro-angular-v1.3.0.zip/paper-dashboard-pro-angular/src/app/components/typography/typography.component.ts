import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'typography-cmp',
    templateUrl: 'typography.component.html'
})

export class TypographyComponent{}
