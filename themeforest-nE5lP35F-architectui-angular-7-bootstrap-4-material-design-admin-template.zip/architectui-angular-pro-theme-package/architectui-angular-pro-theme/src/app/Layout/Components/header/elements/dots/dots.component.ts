import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dots',
  templateUrl: './dots.component.html',
})
export class DotsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
