import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monitoring',
  templateUrl: './monitoring.component.html',
  styles: []
})
export class MonitoringComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
