import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailbox',
  templateUrl: './mailbox.component.html',
  styles: []
})
export class MailboxComponent implements OnInit {
  toggleMobileSidebar: any;

  constructor() { }

  ngOnInit() {
  }

}
